# Simple Theme Preset

A basic e-commerce theme with React components.

## Components
- Header with navigation and search
- Footer with company info
- Product grid layout

## Usage
Customize these components for your store!