import React from "react";

interface HeaderProps {
	logo?: string;
	navigation?: Array<{ label: string; href: string }>;
	showSearch?: boolean;
}

const Header: React.FC<HeaderProps> = ({
	logo = "/logo.svg",
	navigation = [],
	showSearch = true,
}) => {
	return (
		<header className="bg-white shadow-md sticky top-0 z-50">
			<div className="container mx-auto px-4 py-4">
				<div className="flex items-center justify-between">
					<div className="flex items-center">Theme 02</div>

					<nav className="hidden md:flex space-x-8">
						{navigation.map((item, index) => (
							<a
								key={index}
								href={item.href}
								className="text-gray-700 hover:text-blue-600 transition-colors font-medium">
								{item.label}
							</a>
						))}
					</nav>

					{showSearch && (
						<div className="flex items-center space-x-4">
							<input
								type="text"
								placeholder="Search products..."
								className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 w-64"
							/>
							<button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
								Search
							</button>
						</div>
					)}
				</div>
			</div>
		</header>
	);
};

export default Header;
