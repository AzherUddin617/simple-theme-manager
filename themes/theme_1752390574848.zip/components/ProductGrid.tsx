import React from "react";

interface Product {
	id: string;
	name: string;
	price: number;
	image: string;
}

interface ProductGridProps {
	products: Product[];
	onProductClick?: (product: Product) => void;
}

const ProductGrid: React.FC<ProductGridProps> = ({
	products,
	onProductClick,
}) => {
	return (
		<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
			{products.map((product) => (
				<div
					key={product.id}
					className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow cursor-pointer"
					onClick={() => onProductClick?.(product)}>
					<div className="aspect-square bg-gray-100">
						<img
							src={product.image}
							alt={product.name}
							className="w-full h-full object-cover"
						/>
					</div>
					<div className="p-4">
						<h3 className="text-lg font-semibold text-gray-900 mb-2">
							{product.name}
						</h3>
						<p>Product ID: {product.id}</p>
						<p className="text-xl font-bold text-blue-600">
							${product.price.toFixed(2)}
						</p>
					</div>
				</div>
			))}
		</div>
	);
};

export default ProductGrid;
